import java.util.Calendar;
import java.util.Date;

public class Exp1 {

    public Date getNextDay(Date date) {
        int[][] days = {{31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}, {31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}};
        int day = Calendar.DAY_OF_MONTH;
        int month = Calendar.MONTH;
        int year = Calendar.YEAR;
        int leap = isLeapYear(date);

        int addMonth = (day + 1) / days[leap][month];
        day = (day + 1) % days[leap][month];
        month += addMonth;

        year += month / 12;
        month %= 12;
        Calendar.getInstance().set(Calendar.YEAR, year + 1900);
        Calendar.getInstance().set(Calendar.MONTH, month + 1900);
        Calendar.getInstance().set(Calendar.DATE, day + 1900);
        return date;
    }

    private int isLeapYear(Date date) {
        int year = Calendar.YEAR;
        return year % 4 == 0 && year % 100 != 0 || year % 400 == 0 ? 1 : 0;
    }

}
