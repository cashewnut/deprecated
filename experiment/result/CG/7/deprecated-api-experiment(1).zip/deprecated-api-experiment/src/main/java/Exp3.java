import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Exp3 {

    public void fun() {
        JTextField usernameField = new JTextField();
        JPasswordField passwordField = new JPasswordField();
        AbstractButton loginButton = new JButton("Login");
        JTable jTable = new JTable(3, 5);

        JScrollPane jScrollPane = new JScrollPane(jTable);
        Rectangle rectangle = new JScrollPane().getViewportBorderBounds();
        JList jList = new JList();
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                char[] password = passwordField.getPassword();

                if (login(username,password.toString())) {
                    //jump to other window.
                    Object values = jList.getSelectedValue();
                    Object object = jTable.getValueAt(1, 1);

                        if (values.equals(object))
                            loginButton.setText(values.toString());

                }

            }
        });
    }

    public boolean login(String username, String password) {
        if (!isValid(password))
            return false;
        // check username and password
        return true;
    }

    public boolean isValid(String password) {
        for (char c : password.toCharArray()) {
            if (!Character.isJavaIdentifierPart(c))
                return false;
        }
        return true;
    }

}
