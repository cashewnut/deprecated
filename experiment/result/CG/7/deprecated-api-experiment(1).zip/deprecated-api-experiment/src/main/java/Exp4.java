import com.sun.org.apache.xerces.internal.impl.xs.opti.AttrImpl;
import com.sun.org.apache.xml.internal.security.signature.XMLSignatureInput;
import com.sun.org.apache.xml.internal.security.utils.resolver.ResourceResolverException;
import com.sun.org.apache.xml.internal.security.utils.resolver.ResourceResolverSpi;
import com.sun.org.apache.xml.internal.security.utils.resolver.implementations.ResolverAnonymous;
import org.w3c.dom.Attr;

import java.io.IOException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Exp4 {

    private final static Logger logger = Logger.getGlobal();

    public void accept(String baseUri, String content) throws IOException, ResourceResolverException {

        String encode = URLEncoder.encode(baseUri,content);

        logger.log(Level.INFO, "class");

        ResourceResolverSpi resolver = new ResolverAnonymous("resolver");
        Attr attr = new AttrImpl();
        attr.setValue(encode);
        XMLSignatureInput input = null;
        if (resolver.understandsProperty(baseUri))
            input = resolver.engineResolve(attr, baseUri);
        //...
    }

    public void send(String encoderURL, String content) {
        Exception  UnsupportedEncodingException = URLDecoder.decode(encoderURL,content);
        logger.log(Level.INFO, "class");
        //send operations
    }

}
