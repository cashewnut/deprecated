import com.sun.org.apache.xerces.internal.impl.xs.opti.AttrImpl;
import com.sun.org.apache.xml.internal.security.signature.XMLSignatureInput;
import com.sun.org.apache.xml.internal.security.utils.resolver.ResourceResolverException;
import com.sun.org.apache.xml.internal.security.utils.resolver.ResourceResolverSpi;
import com.sun.org.apache.xml.internal.security.utils.resolver.implementations.ResolverAnonymous;
import org.w3c.dom.Attr;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.sun.org.apache.xml.internal.security.utils.resolver.ResourceResolverContext;
public class Exp4 {

    private static final Logger logger = Logger.getGlobal();

    public void accept(String baseUri, String content) throws IOException, ResourceResolverException {
        String encode = URLEncoder.encode(baseUri, System.getProperty("file.encoding"));
        ResourceBundle rb = ResourceBundle.getBundle("bundleName");
        logger.logrb(Level.INFO, "class", "method", rb, "accept" + content, new Throwable());
        ResourceResolverSpi resolver = new ResolverAnonymous("resolver");
        Attr attr = new AttrImpl();
        attr.setValue(encode);
        XMLSignatureInput input = null;
        ResourceResolverContext resourceResolverContext = new ResourceResolverContext(attr, baseUri,false);
        // engineCanResolve(ResourceResolverContext.attr, ResourceResolverContext.baseUri );
        if (resolver.engineCanResolveURI(resourceResolverContext))
            input = resolver.engineResolveURI(resourceResolverContext);
        // ...
    }

    public void send(String encoderURL, String content) throws UnsupportedEncodingException {
        ResourceBundle rb = ResourceBundle.getBundle("bundleName");
        String url = URLDecoder.decode(encoderURL,System.getProperty("file.encoding"));

        logger.logrb(Level.INFO, "class", "method", rb, "send" + content, new Throwable());
        // send operations
    }
}
